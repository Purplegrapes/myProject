﻿var reds = document.getElementsByClassName('red');
var move = function (x,y) {
    for (var i = 0; i < reds.length; i++) {
        reds[i].addEventListener('click', function () {
            this.style.top = x + "px";
            this.style.left = y + 'px';
        });

    };
}
var firstStep= function () { 
    console.log(number);
    if (number==6) {
        move(160,430);
        if (number == 1) {
            move(20, 40);
        }
    }
};
